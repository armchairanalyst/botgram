


def PrintExceptionError(message, e):
    print("----------------- EXCEPTION --------------------")
    print("\t\t "+ str(message))
    print("\t\t "+ str(e))
    print("----------------- EXCEPTION --------------------")